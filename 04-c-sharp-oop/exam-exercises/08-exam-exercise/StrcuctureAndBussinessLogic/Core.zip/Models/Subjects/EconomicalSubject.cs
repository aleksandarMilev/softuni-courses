﻿namespace UniversityCompetition.Models.Subjects
{
    public class EconomicalSubject : Subject
    {
        private const double EconomicalSubjectRate = 1;

        public EconomicalSubject(int id, string name)
            : base(id, name, EconomicalSubjectRate)
        {
        }
    }
}
