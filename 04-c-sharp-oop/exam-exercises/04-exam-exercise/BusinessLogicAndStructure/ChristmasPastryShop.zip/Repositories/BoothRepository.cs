﻿using ChristmasPastryShop.Models.Booths.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System.Collections.Generic;

namespace ChristmasPastryShop.Repositories
{
    public class BoothRepository : IRepository<IBooth>
    {
        public IReadOnlyCollection<IBooth> Models => throw new System.NotImplementedException();

        public void AddModel(IBooth model)
        {
            throw new System.NotImplementedException();
        }
    }
}
