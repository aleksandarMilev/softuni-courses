﻿using ChristmasPastryShop.Models.Cocktails.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System.Collections.Generic;

namespace ChristmasPastryShop.Repositories
{
    public class CocktailRepository : IRepository<ICocktail>
    {
        public IReadOnlyCollection<ICocktail> Models => throw new System.NotImplementedException();

        public void AddModel(ICocktail model)
        {
            throw new System.NotImplementedException();
        }
    }
}
