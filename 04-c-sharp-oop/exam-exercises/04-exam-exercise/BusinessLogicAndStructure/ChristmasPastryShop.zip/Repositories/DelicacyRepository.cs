﻿using ChristmasPastryShop.Models.Delicacies.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System.Collections.Generic;

namespace ChristmasPastryShop.Repositories
{
    public class DelicacyRepository : IRepository<IDelicacy>
    {
        public IReadOnlyCollection<IDelicacy> Models => throw new System.NotImplementedException();

        public void AddModel(IDelicacy model)
        {
            throw new System.NotImplementedException();
        }
    }
}
