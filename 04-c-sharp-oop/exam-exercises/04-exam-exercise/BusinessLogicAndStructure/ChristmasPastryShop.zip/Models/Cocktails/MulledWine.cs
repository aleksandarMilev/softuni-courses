﻿namespace ChristmasPastryShop.Models.Cocktails
{
    public class MulledWine : Cocktail
    {
    }
}
