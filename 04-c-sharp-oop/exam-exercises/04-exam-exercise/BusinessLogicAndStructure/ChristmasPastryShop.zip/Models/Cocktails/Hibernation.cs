﻿
namespace ChristmasPastryShop.Models.Cocktails
{
    public class Hibernation : Cocktail
    {
    }
}
