﻿using ChristmasPastryShop.Models.Cocktails.Contracts;

namespace ChristmasPastryShop.Models.Cocktails
{
    public abstract class Cocktail : ICocktail
    {
        public string Name => throw new System.NotImplementedException();

        public string Size => throw new System.NotImplementedException();

        public double Price => throw new System.NotImplementedException();
    }
}
