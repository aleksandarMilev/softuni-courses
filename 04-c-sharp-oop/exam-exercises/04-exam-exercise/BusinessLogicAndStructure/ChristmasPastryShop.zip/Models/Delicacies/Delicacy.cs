﻿using ChristmasPastryShop.Models.Delicacies.Contracts;

namespace ChristmasPastryShop.Models.Delicacies
{
    public abstract class Delicacy : IDelicacy
    {
        public string Name => throw new System.NotImplementedException();

        public double Price => throw new System.NotImplementedException();
    }
}
