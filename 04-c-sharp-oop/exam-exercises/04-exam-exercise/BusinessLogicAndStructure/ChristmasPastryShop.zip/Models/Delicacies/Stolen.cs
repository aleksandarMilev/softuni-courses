﻿namespace ChristmasPastryShop.Models.Delicacies
{
    public class Stolen : Delicacy
    {

    }
}
