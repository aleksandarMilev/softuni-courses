﻿
namespace ChristmasPastryShop.Models.Delicacies
{
    public class Gingerbread : Delicacy
    {
    }
}
