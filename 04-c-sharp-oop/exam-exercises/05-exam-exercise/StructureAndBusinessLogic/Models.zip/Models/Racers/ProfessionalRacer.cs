﻿namespace CarRacing.Models.Racers
{
    public class ProfessionalRacer : Racer
    {
    }
}
