﻿namespace CarRacing.Models.Racers
{
    public class StreetRacer : Racer
    {
    }
}
