﻿using CarRacing.Models.Cars.Contracts;

namespace CarRacing.Models.Cars
{
    public abstract class Car : ICar
    {
        public string Make => throw new System.NotImplementedException();

        public string Model => throw new System.NotImplementedException();

        public string VIN => throw new System.NotImplementedException();

        public int HorsePower => throw new System.NotImplementedException();

        public double FuelAvailable => throw new System.NotImplementedException();

        public double FuelConsumptionPerRace => throw new System.NotImplementedException();

        public void Drive()
        {
            throw new System.NotImplementedException();
        }
    }
}
