﻿namespace CarRacing.Models.Cars
{
    public class SuperCar : Car
    {
    }
}
