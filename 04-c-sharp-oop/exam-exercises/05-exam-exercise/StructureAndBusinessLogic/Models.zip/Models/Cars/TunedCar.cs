﻿namespace CarRacing.Models.Cars
{
    public class TunedCar : Car
    {
    }
}
